import matplotlib.pyplot as plt
import numpy as np

# 数据
noise = np.array([0, 5, 10, 15, 20, 25, 30, 35, 40])
fidelity_I = [0.999999, 0.999986, 0.999785, 0.99893, 0.996713, 0.992295, 0.984836, 0.973708, 0.958674]
fidelity_X = [0.999999, 0.999712, 0.998844, 0.997186, 0.994478, 0.990372, 0.984484, 0.976451, 0.966]
fidelity_H = [0.999999, 0.998984, 0.99598, 0.991096, 0.98448, 0.976436, 0.967084, 0.956626, 0.945137]
fidelity_Y = [0.999999, 0.999722, 0.998846, 0.997114, 0.994426, 0.990364, 0.984484, 0.976448, 0.966]
fidelity_no_opti = [0.999999, 0.998439257, 0.993798993, 0.986203203, 0.975852318, 0.963014236, 0.948012487, 0.931212194, 0.913004613]

# 绘图
plt.figure(figsize=(7.2, 4.5))
plt.plot(noise, fidelity_I, marker='o', linestyle='-', color='black', label='I gate')
plt.plot(noise, fidelity_X, marker='^', linestyle='--', color='blue', label='X gate')
plt.plot(noise, fidelity_H, marker='s', linestyle='-.', color='green', label='H gate')
plt.plot(noise, fidelity_Y, marker='D', linestyle=':', color='red', label='Y gate')
plt.plot(noise, fidelity_no_opti, marker='*', linestyle='-', color='orange', linewidth=2, markersize=11, label='No optimization')

plt.xlabel('Noise Strength', fontsize=13)
plt.ylabel('Fidelity', fontsize=13)
plt.title('Single-Qubit Gate Fidelity vs. Noise Strength', fontsize=14)
plt.ylim(0.9, 1.01)
plt.xlim(-1, 41)
plt.grid(axis='y', linestyle=':', alpha=0.7)
plt.legend(loc='lower left', fontsize=12, frameon=True)
plt.tight_layout()

# 可选：保存为高分辨率PDF
# plt.savefig("single_qubit_gate_fidelity_vs_noise_with_noopti.pdf", bbox_inches='tight')

plt.show()
