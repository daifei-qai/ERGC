# import matplotlib.pyplot as plt
# import numpy as np

# # 数据
# noise = np.array([0, 5, 10, 15, 20, 25, 30, 35, 40])

# I = np.array([0.999999, 0.999986, 0.999785, 0.99893, 0.996713, 0.992295, 0.984836, 0.973708, 0.958674])
# I_no_opti = np.array([1, 0.996159, 0.984857, 0.96674, 0.942832, 0.914454, 0.883127, 0.850462, 0.818041])

# H = np.array([0.999999, 0.998984, 0.99598, 0.991096, 0.98448, 0.976436, 0.967084, 0.956626, 0.945137])
# H_no_opti = np.array([1, 0.997663, 0.990757, 0.979601, 0.964714, 0.946802, 0.926713, 0.905395, 0.883811])

# X = np.array([0.999999, 0.999712, 0.998844, 0.997186, 0.994478, 0.990372, 0.984484, 0.976451, 0.966])
# X_no_opti = np.array([1, 0.998439257, 0.993798993, 0.986203203, 0.975852318, 0.963014236, 0.948012487, 0.931212194, 0.913004613])

# Y = np.array([0.999999, 0.999722, 0.998846, 0.997114, 0.994426, 0.990364, 0.984484, 0.976448, 0.966])
# Y_no_opti = np.array([1, 0.998439, 0.993799, 0.986203, 0.975852, 0.963014, 0.948012, 0.931212, 0.913005])

# # 颜色与标签
# gate_data = [
#     ('I', I, I_no_opti, 'black'),
#     ('H', H, H_no_opti, 'blue'),
#     ('X', X, X_no_opti, 'green'),
#     ('Y', Y, Y_no_opti, 'red')
# ]

# # 图形参数
# plt.rcParams.update({
#     "font.size": 16,
#     "axes.labelsize": 16,
#     "legend.fontsize": 13,
#     "xtick.labelsize": 16,
#     "ytick.labelsize": 16,
#     "lines.linewidth": 2,
#     "axes.linewidth": 1.2,
#     "font.family": "serif"
# })

# fig, axs = plt.subplots(2, 2, sharex=True, sharey=True)
# axs = axs.flatten()

# for idx, (gate, data, data_no, color) in enumerate(gate_data):
#     ax = axs[idx]
#     # 优化后
#     ax.plot(noise, data, marker='o', color=color, label=f'{gate} (ERGC)', markersize=6)
#     # 未优化
#     ax.plot(noise, data_no, marker='s', linestyle='--', color='orange', label=f'{gate} (Uncorrected)', markersize=6)
#     ax.set_title(f'{gate} Gate')
    
#     if idx % 2 == 0:
#         ax.set_ylabel('F')

#     if idx % 2 == 2:
#         ax.set_xlabel('$\Delta \omega$(MHz)')

#     ax.set_ylim(0.8, 1.01)
#     ax.set_xlim(0, 40)
#     ax.grid(True, which='both', linestyle=':', linewidth=1, alpha=0.6)
#     ax.legend(loc='lower left', frameon=False)
#     ax.tick_params(axis='both', direction='in')
    

# # 统一y轴标签
# # fig.text(0.04, 0.5, 'Fidelity', va='center', rotation='vertical', fontsize=16)
# fig.text(0.5, 0.03, '$\Delta {\omega}$(MHz)', ha='center', fontsize=16)

# plt.tight_layout(rect=[0.05, 0.05, 1, 1])
# plt.subplots_adjust(wspace=0.18, hspace=0.22)
# plt.show()

import matplotlib.pyplot as plt
import numpy as np

# 数据
noise = np.array([0, 5, 10, 15, 20, 25, 30, 35, 40])

I = np.array([0.999999, 0.999986, 0.999785, 0.99893, 0.996713, 0.992295, 0.984836, 0.973708, 0.958674])
I_no_opti = np.array([1, 0.996159, 0.984857, 0.96674, 0.942832, 0.914454, 0.883127, 0.850462, 0.818041])

H = np.array([0.999999, 0.998984, 0.99598, 0.991096, 0.98448, 0.976436, 0.967084, 0.956626, 0.945137])
H_no_opti = np.array([1, 0.997663, 0.990757, 0.979601, 0.964714, 0.946802, 0.926713, 0.905395, 0.883811])

X = np.array([0.999999, 0.999712, 0.998844, 0.997186, 0.994478, 0.990372, 0.984484, 0.976451, 0.966])
X_no_opti = np.array([1, 0.998439257, 0.993798993, 0.986203203, 0.975852318, 0.963014236, 0.948012487, 0.931212194, 0.913004613])

Y = np.array([0.999999, 0.999722, 0.998846, 0.997114, 0.994426, 0.990364, 0.984484, 0.976448, 0.966])
Y_no_opti = np.array([1, 0.998439, 0.993799, 0.986203, 0.975852, 0.963014, 0.948012, 0.931212, 0.913005])

# 颜色与标签
gate_data = [
    ('I', I, I_no_opti, 'black'),
    ('H', H, H_no_opti, 'blue'),
    ('X', X, X_no_opti, 'green'),
    ('Y', Y, Y_no_opti, 'red')
]

# 图形参数
plt.rcParams.update({
    "font.size": 16,
    "axes.labelsize": 16,
    "legend.fontsize": 13,
    "xtick.labelsize": 16,
    "ytick.labelsize": 16,
    "lines.linewidth": 2,
    "axes.linewidth": 1.2,
    "font.family": "serif"
})

fig, axs = plt.subplots(2, 2, sharex=True, sharey=True)
axs = axs.flatten()

corner_labels = ['(a)', '(b)', '(c)', '(d)']

for idx, (gate, data, data_no, color) in enumerate(gate_data):
    ax = axs[idx]
    # 优化后
    ax.plot(noise, data, marker='o', color=color, label=f'{gate} (ERGC)', markersize=6)
    # 未优化
    ax.plot(noise, data_no, marker='s', linestyle='--', color='orange', label=f'{gate} (Uncorrected)', markersize=6)
    ax.set_title(f'{gate} Gate',  fontsize=16)
    
    # 左上角角标
    # ax.text(-0.18, 1.15, corner_labels[idx], transform=ax.transAxes,
    #         fontsize=16, va='top', ha='left')

    if idx % 2 == 0:
        ax.set_ylabel('F',fontsize=16)
        ax.text(-0.32, 1.15, corner_labels[idx], transform=ax.transAxes,
            fontsize=16, va='top', ha='left')
        
    if idx % 2 != 0:
        ax.text(-0.18, 1.15, corner_labels[idx], transform=ax.transAxes,
            fontsize=16, va='top', ha='left')
    

    # if idx // 2 == 1:
    #     ax.set_xlabel('$\Delta \omega$ (MHz)')

    ax.set_ylim(0.77, 1.03)
    ax.set_xlim(0, 40)
    ax.grid(True, which='both', linestyle=':', linewidth=1, alpha=0.6)
    ax.legend(loc='lower left', frameon=False)
    ax.tick_params(axis='both', direction='in')

# x轴大标签，微调横纵坐标以居中
fig.text(0.55, 0.01, r'$\Delta\omega$ (MHz)', ha='center', va='bottom', fontsize=16)

plt.tight_layout(rect=[0.01, 0.05, 1, 1])
plt.subplots_adjust(wspace=0.24, hspace=0.28)
plt.show()
