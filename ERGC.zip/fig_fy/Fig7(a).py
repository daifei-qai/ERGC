
# import numpy as np
# import matplotlib.pyplot as plt
# from matplotlib.ticker import MultipleLocator

# # 数据
# noise_levels = np.array([0, 5, 10, 15, 20, 25, 30, 35, 40])
# fidelity_matrix = np.array([
#     [0.999999, 0.99311, 0.97323, 0.94259, 0.90444, 0.86256, 0.82062, 0.78164, 0.74765],  # 优化于0
#     [0.99987, 0.99964, 0.99882, 0.99699, 0.99355, 0.98776, 0.97891, 0.96647, 0.95028],   # 优化于10
#     [0.99838, 0.99831, 0.99796, 0.9969, 0.99448, 0.9899, 0.98238, 0.9713, 0.95638],     # 优化于20
#     [0.99238, 0.99257, 0.99296, 0.99312, 0.99234, 0.98976, 0.98448, 0.97574, 0.96309],  # 优化于30
#     [0.97935, 0.97983, 0.98113, 0.98276, 0.98399, 0.98388, 0.98141, 0.97566, 0.96600],  # 优化于40
# ])
# opt_points = [0, 10, 20, 30, 40]
# colors = ['#377eb8', '#4daf4a', '#984ea3', '#ff7f00', '#e41a1c']
# plt.rcParams.update({
#     "font.size": 20,
#     "axes.labelsize": 16,
#     "legend.fontsize": 16,
#     "xtick.labelsize": 13,
#     "ytick.labelsize": 13,
#     "lines.linewidth": 2,
#     "axes.linewidth": 1.2,
#     "font.family": "serif"
# })

# fig, ax = plt.subplots()

# for i, f in enumerate(fidelity_matrix):
#     x = noise_levels
#     # ax.plot(x, f, color=colors[i], linewidth=2, label=f'Optimized at {opt_points[i]} MHz')
#     ax.plot(x, f, color=colors[i], linewidth=2)

# # 画竖向虚线
# for i in opt_points:
#     ax.axvline(x=i, ymin=0, ymax=1.0, color=colors[opt_points.index(i)], linestyle='--', alpha=0.5)

# ax.set_xlabel('$\Delta{\omega}$(MHz)')
# ax.set_ylabel('F')
# ax.set_xlim(noise_levels.min(), noise_levels.max())
# ax.set_ylim(0.92, 1.01)
# ax.xaxis.set_major_locator(MultipleLocator(5))
# ax.yaxis.set_major_locator(MultipleLocator(0.02))
# ax.tick_params(axis='both', which='major', labelsize=16)
# ax.grid(True, linestyle='--', alpha=0.7)
# ax.legend(loc='lower left', fontsize=11, frameon=False)
# ax.tick_params(axis='both', direction='in')
# plt.tight_layout()
# plt.show()

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.ticker import MultipleLocator

# 数据
noise_levels = np.array([0, 5, 10, 15, 20, 25, 30, 35, 40])
fidelity_matrix = np.array([
    [0.999999, 0.99311, 0.97323, 0.94259, 0.90444, 0.86256, 0.82062, 0.78164, 0.74765],  # 优化于0
    [0.99987, 0.99964, 0.99882, 0.99699, 0.99355, 0.98776, 0.97891, 0.96647, 0.95028],   # 优化于10
    [0.99838, 0.99831, 0.99796, 0.9969, 0.99448, 0.9899, 0.98238, 0.9713, 0.95638],     # 优化于20
    [0.99238, 0.99257, 0.99296, 0.99312, 0.99234, 0.98976, 0.98448, 0.97574, 0.96309],  # 优化于30
    [0.97935, 0.97983, 0.98113, 0.98276, 0.98399, 0.98388, 0.98141, 0.97566, 0.96600],  # 优化于40
])
opt_points = [0, 10, 20, 30, 40]
colors = ['#377eb8', '#4daf4a', '#984ea3', '#ff7f00', '#e41a1c']

plt.rcParams.update({
    "font.size": 20,
    "axes.labelsize": 16,
    "legend.fontsize": 16,
    "xtick.labelsize": 13,
    "ytick.labelsize": 13,
    "lines.linewidth": 2,
    "axes.linewidth": 1.2,
    "font.family": "serif"
})

fig, ax = plt.subplots()

for i, f in enumerate(fidelity_matrix):
    x = noise_levels
    # label = r'$\Delta\omega = {}$ MHz'.format(opt_points[i])
    label = r'${}$ '.format(opt_points[i])
    ax.plot(x, f, color=colors[i], linewidth=2, label=label)

# 画竖向虚线
for i in opt_points:
    ax.axvline(x=i, ymin=0, ymax=1.0, color=colors[opt_points.index(i)], linestyle='--', alpha=0.5)

ax.set_xlabel(r'$\Delta\omega$ (MHz)')
ax.set_ylabel('F')
ax.set_xlim(noise_levels.min(), noise_levels.max())
ax.set_ylim(0.92, 1.01)
ax.xaxis.set_major_locator(MultipleLocator(5))
ax.yaxis.set_major_locator(MultipleLocator(0.02))
ax.tick_params(axis='both', which='major', labelsize=16)
ax.grid(True, linestyle='--', alpha=0.7)
ax.legend(loc='lower left', fontsize=14, frameon=False, handlelength=2)
ax.tick_params(axis='both', direction='in')
plt.tight_layout()
plt.show()
