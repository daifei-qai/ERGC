# import numpy as np
# import matplotlib.pyplot as plt
# from mpl_toolkits.mplot3d import Axes3D
# from matplotlib.ticker import MultipleLocator

# # 2D图数据
# noise_levels = np.array([0, 5, 10, 15, 20, 25, 30, 35, 40])
# fidelity_matrix = np.array([
#     [0.999999, 0.99311, 0.97323, 0.94259, 0.90444, 0.86256, 0.82062, 0.78164, 0.74765],  # 优化于0
#     [0.99987, 0.99964, 0.99882, 0.99699, 0.99355, 0.98776, 0.97891, 0.96647, 0.95028],   # 优化于10
#     [0.99838, 0.99831, 0.99796, 0.9969, 0.99448, 0.9899, 0.98238, 0.9713, 0.95638],     # 优化于20
#     [0.99238, 0.99257, 0.99296, 0.99312, 0.99234, 0.98976, 0.98448, 0.97574, 0.96309],  # 优化于30
#     [0.97935, 0.97983, 0.98113, 0.98276, 0.98399, 0.98388, 0.98141, 0.97566, 0.96600],  # 优化于40
# ])
# opt_points = [0, 10, 20, 30, 40]
# colors = ['#377eb8', '#4daf4a', '#984ea3', '#ff7f00', '#e41a1c']

# # 3D图数据
# crosstalk_values = np.array([
#     0,
#     5e6,
#     1e7,
#     1.5e7,
#     2e7,
#     2.5e7,
#     3e7,
#     3.5e7,
#     4e7,
#     4.5e7,
#     5e7,
#     5.5e7,
#     6e7,
#     6.5e7,
#     7e7,
#     7.5e7,
#     8e7,
#     8.5e7,
#     9e7,
#     9.5e7,
#     1e8
# ])

# fidelities_all = [
#     [0.999999, 0.997828, 0.991219, 0.980067, 0.96436, 0.944186, 0.919736, 0.891304, 0.859287, 0.824178, 0.786553, 0.747064, 0.706415, 0.665352, 0.624631, 0.585007, 0.5472, 0.511882, 0.479647, 0.450994, 0.426315],
#     [0.984494, 0.996155, 0.999998, 0.996064, 0.984578, 0.965938, 0.940702, 0.909564, 0.873338, 0.832931, 0.789319, 0.743521, 0.69657, 0.649489, 0.603264, 0.55882, 0.516994, 0.47852, 0.444009, 0.413933, 0.388619],
#     [0.97723, 0.987197, 0.994323, 0.998588, 1.0, 0.998586, 0.994399, 0.987514, 0.978027, 0.966059, 0.951754, 0.93528, 0.916826, 0.896609, 0.874864, 0.851851, 0.827847, 0.803146, 0.778056, 0.75289, 0.727966],
#     [0.939884, 0.957558, 0.972455, 0.984329, 0.992974, 0.998233, 1.0, 0.998226, 0.992921, 0.984155, 0.972058, 0.956822, 0.938696, 0.917982, 0.895032, 0.870241, 0.844038, 0.816879, 0.789239, 0.761599, 0.734438],
#     [0.894391, 0.917443, 0.938195, 0.956355, 0.971656, 0.983857, 0.992753, 0.998176, 1.0, 0.998146, 0.992586, 0.983345, 0.970499, 0.954181, 0.934575, 0.911918, 0.886496, 0.858637, 0.828711, 0.79712, 0.764292],
#     [0.838305, 0.864254, 0.889077, 0.912368, 0.93372, 0.95273, 0.969009, 0.982189, 0.991936, 0.997955, 1.0, 0.997881, 0.991475, 0.980727, 0.965662, 0.946382, 0.92307, 0.895993, 0.865495, 0.831996, 0.795985],
#     [0.830662, 0.853885, 0.87633, 0.897676, 0.917626, 0.935903, 0.952256, 0.966465, 0.978342, 0.987734, 0.994523, 0.998626, 1.0, 0.998635, 0.994559, 0.987833, 0.978547, 0.966826, 0.952816, 0.936691, 0.918642],
#     [0.475596, 0.511019, 0.551954, 0.597466, 0.646384, 0.697337, 0.748811, 0.799207, 0.846903, 0.890327, 0.928025, 0.958725, 0.981396, 0.995293, 0.999994, 0.99542, 0.981835, 0.959839, 0.930335, 0.894487, 0.853663],
#     [0.450937, 0.480459, 0.514878, 0.553624, 0.595962, 0.641001, 0.687727, 0.735022, 0.781705, 0.826567, 0.868408, 0.90608, 0.938523, 0.964809, 0.984167, 0.99602, 1.0, 0.995967, 0.984014, 0.964464, 0.937862],
#     [0.461438, 0.487231, 0.516516, 0.549029, 0.584395, 0.622134, 0.661663, 0.702307, 0.743319, 0.783895, 0.823195, 0.860375, 0.894604, 0.925096, 0.951133, 0.97209, 0.987452, 0.996836, 1.0, 0.996852, 0.987453],
#     [0.397328, 0.417749, 0.441691, 0.469208, 0.500258, 0.534682, 0.572198, 0.61239, 0.654705, 0.698454, 0.74282, 0.786869, 0.829571, 0.869826, 0.906498, 0.938448, 0.964582, 0.983892, 0.995502, 0.998717, 0.993062],
# ]

# opt_indices = [0, 2, 4, 6, 8, 10]
# opt_crosstalks = [0, 20, 40, 60, 80, 100]

# fidelities = [fidelities_all[i] for i in opt_indices]

# # 学术美观设置
# plt.rcParams.update({
#     'font.size': 10,
#     'axes.labelweight': 'bold',
#     'axes.titlesize': 8,
#     'figure.figsize': (8, 4),
#     'figure.dpi': 150,
#     'lines.linewidth': 2,
#     'lines.markersize': 3
# })

# fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(8, 4))

# # 2D图
# for i, f in enumerate(fidelity_matrix):
#     x = noise_levels
#     ax1.plot(x, f, color=colors[i], linewidth=2)
    
#     # 找到每条线的最高点并画竖向虚线到保真度=1的位置
#     max_idx = np.argmax(f)
#     max_x = x[max_idx]
#     max_y = f[max_idx]
#     ax1.axvline(x=max_x, ymin=0, ymax=0.99, color=colors[i], linestyle='--', alpha=0.5)

# ax1.set_xlabel('Noise Strength (MHz)', fontsize=10, fontweight='bold')
# ax1.set_ylabel('F', fontsize=10, fontweight='bold')
# ax1.set_xlim(noise_levels.min(), noise_levels.max())
# ax1.set_ylim(0.8, 1.01)
# ax1.xaxis.set_major_locator(MultipleLocator(5))
# ax1.yaxis.set_major_locator(MultipleLocator(0.05))
# ax1.tick_params(axis='both', which='major', labelsize=8)
# ax1.grid(True, linestyle='--', alpha=0.7)
# ax1.set_title('(a)', loc='left', fontweight='bold')

# # 3D图
# for i, f in enumerate(fidelities):
#     x = crosstalk_values / 1e6  # MHz
#     ax2.plot(x, f, color=f'C{i}', linewidth=2)
    
#     # 找到每条线的最高点并画竖向虚线到保真度=1的位置
#     max_idx = np.argmax(f)
#     max_x = x[max_idx]
#     max_y = f[max_idx]
#     ax2.axvline(x=max_x, ymin=0, ymax=0.99, color=f'C{i}', linestyle='--', alpha=0.5)

# ax2.set_xlabel('Crosstalk (MHz)', fontsize=10, fontweight='bold')
# ax2.set_ylabel('F', fontsize=10, fontweight='bold')
# ax2.set_xlim(0, x[-1] + 10)
# ax2.set_ylim(0.4, 1.05)
# ax2.xaxis.set_major_locator(MultipleLocator(20))
# ax2.yaxis.set_major_locator(MultipleLocator(0.1))
# ax2.tick_params(axis='both', which='major', labelsize=8)
# ax2.grid(True, linestyle='--', alpha=0.7)
# ax2.set_title('(b)', loc='left', fontweight='bold')

# plt.subplots_adjust(wspace=0.4)
# plt.savefig('figure.pdf', bbox_inches='tight')
# plt.show

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.ticker import MultipleLocator
from matplotlib.gridspec import GridSpec

# 数据
noise_levels = np.array([0, 5, 10, 15, 20, 25, 30, 35, 40])
fidelity_matrix = np.array([
    [0.999999, 0.99311, 0.97323, 0.94259, 0.90444, 0.86256, 0.82062, 0.78164, 0.74765],  # 优化于0
    [0.99987, 0.99964, 0.99882, 0.99699, 0.99355, 0.98776, 0.97891, 0.96647, 0.95028],   # 优化于10
    [0.99838, 0.99831, 0.99796, 0.9969, 0.99448, 0.9899, 0.98238, 0.9713, 0.95638],     # 优化于20
    [0.99238, 0.99257, 0.99296, 0.99312, 0.99234, 0.98976, 0.98448, 0.97574, 0.96309],  # 优化于30
    [0.97935, 0.97983, 0.98113, 0.98276, 0.98399, 0.98388, 0.98141, 0.97566, 0.96600],  # 优化于40
])
opt_points = [0, 10, 20, 30, 40]
colors = ['#377eb8', '#4daf4a', '#984ea3', '#ff7f00', '#e41a1c']

# Crosstalk 横轴数据（单位：Hz）
crosstalk_values = np.array([
    0,
    5e6,
    1e7,
    1.5e7,
    2e7,
    2.5e7,
    3e7,
    3.5e7,
    4e7,
    4.5e7,
    5e7,
    5.5e7,
    6e7,
    6.5e7,
    7e7,
    7.5e7,
    8e7,
    8.5e7,
    9e7,
    9.5e7,
    1e8
])

# 所有11组保真度
fidelities_all = [
    [0.999999, 0.997828, 0.991219, 0.980067, 0.96436, 0.944186, 0.919736, 0.891304, 0.859287, 0.824178, 0.786553, 0.747064, 0.706415, 0.665352, 0.624631, 0.585007, 0.5472, 0.511882, 0.479647, 0.450994, 0.426315],  # Crosstalk=0优化
    [0.984494, 0.996155, 0.999998, 0.996064, 0.984578, 0.965938, 0.940702, 0.909564, 0.873338, 0.832931, 0.789319, 0.743521, 0.69657, 0.649489, 0.603264, 0.55882, 0.516994, 0.47852, 0.444009, 0.413933, 0.388619],  # Crosstalk=1e7优化
    [0.97723, 0.987197, 0.994323, 0.998588, 1.0, 0.998586, 0.994399, 0.987514, 0.978027, 0.966059, 0.951754, 0.93528, 0.916826, 0.896609, 0.874864, 0.851851, 0.827847, 0.803146, 0.778056, 0.75289, 0.727966],  # Crosstalk=2e7优化
    [0.939884, 0.957558, 0.972455, 0.984329, 0.992974, 0.998233, 1.0, 0.998226, 0.992921, 0.984155, 0.972058, 0.956822, 0.938696, 0.917982, 0.895032, 0.870241, 0.844038, 0.816879, 0.789239, 0.761599, 0.734438],  # Crosstalk=3e7优化
    [0.894391, 0.917443, 0.938195, 0.956355, 0.971656, 0.983857, 0.992753, 0.998176, 1.0, 0.998146, 0.992586, 0.983345, 0.970499, 0.954181, 0.934575, 0.911918, 0.886496, 0.858637, 0.828711, 0.79712, 0.764292],  # Crosstalk=4e7优化
    [0.838305, 0.864254, 0.889077, 0.912368, 0.93372, 0.95273, 0.969009, 0.982189, 0.991936, 0.997955, 1.0, 0.997881, 0.991475, 0.980727, 0.965662, 0.946382, 0.92307, 0.895993, 0.865495, 0.831996, 0.795985],  # Crosstalk=5e7优化
    [0.830662, 0.853885, 0.87633, 0.897676, 0.917626, 0.935903, 0.952256, 0.966465, 0.978342, 0.987734, 0.994523, 0.998626, 1.0, 0.998635, 0.994559, 0.987833, 0.978547, 0.966826, 0.952816, 0.936691, 0.918642],  # Crosstalk=6e7优化
    [0.475596, 0.511019, 0.551954, 0.597466, 0.646384, 0.697337, 0.748811, 0.799207, 0.846903, 0.890327, 0.928025, 0.958725, 0.981396, 0.995293, 0.999994, 0.99542, 0.981835, 0.959839, 0.930335, 0.894487, 0.853663],  # Crosstalk=7e7优化
    [0.450937, 0.480459, 0.514878, 0.553624, 0.595962, 0.641001, 0.687727, 0.735022, 0.781705, 0.826567, 0.868408, 0.90608, 0.938523, 0.964809, 0.984167, 0.99602, 1.0, 0.995967, 0.984014, 0.964464, 0.937862],  # Crosstalk=8e7优化
    [0.461438, 0.487231, 0.516516, 0.549029, 0.584395, 0.622134, 0.661663, 0.702307, 0.743319, 0.783895, 0.823195, 0.860375, 0.894604, 0.925096, 0.951133, 0.97209, 0.987452, 0.996836, 1.0, 0.996852, 0.987453],  # Crosstalk=9e7优化
    [0.397328, 0.417749, 0.441691, 0.469208, 0.500258, 0.534682, 0.572198, 0.61239, 0.654705, 0.698454, 0.74282, 0.786869, 0.829571, 0.869826, 0.906498, 0.938448, 0.964582, 0.983892, 0.995502, 0.998717, 0.993062],  # Crosstalk=1e8优化
]

opt_indices = [0, 2, 4, 6, 8, 10]
opt_crosstalks = [0, 20, 40, 60, 80, 100]  # MHz
fidelities = [fidelities_all[i] for i in opt_indices]

# 学术美观设置
plt.rcParams.update({
    'font.size': 10,
    'axes.labelweight': 'bold',
    'axes.titlesize': 8,
    'figure.figsize': (8, 4),
    'figure.dpi': 150,
    'lines.linewidth': 2,
    'lines.markersize': 3
})

# 创建并排的子图
fig = plt.figure(figsize=(8, 4))
gs = GridSpec(1, 2, figure=fig, wspace=0.4)

# 绘制子图 a
ax1 = fig.add_subplot(gs[0, 0])
for i, f in enumerate(fidelity_matrix):
    x = noise_levels
    ax1.plot(x, f, color=colors[i], linewidth=2)
    
    # 找到每条线的最高点并画竖向虚线到保真度=1的位置
    max_idx = np.argmax(f)
    max_x = x[max_idx]
    max_y = f[max_idx]
    ax1.axvline(x=max_x, ymin=0, ymax=0.99, color=colors[i], linestyle='--', alpha=0.5)

ax1.set_xlabel('Noise Strength (MHz)', fontsize=10, fontweight='bold')
ax1.set_ylabel('F', fontsize=10, fontweight='bold')
ax1.set_xlim(noise_levels.min(), noise_levels.max())
ax1.set_ylim(0.92, 1.01)
ax1.xaxis.set_major_locator(MultipleLocator(5))
ax1.yaxis.set_major_locator(MultipleLocator(0.02))
ax1.tick_params(axis='both', which='major', labelsize=8)
ax1.grid(True, linestyle='--', alpha=0.7)
ax1.set_title('(a)', loc='left', fontsize=10)

# 绘制子图 b
ax2 = fig.add_subplot(gs[0, 1])
for i, f in enumerate(fidelities):
    x = crosstalk_values / 1e6  # MHz
    ax2.plot(x, f, color=f'C{i}', linewidth=2)
    
    # 找到每条线的最高点并画竖向虚线到保真度=1的位置
    max_idx = np.argmax(f)
    max_x = x[max_idx]
    max_y = f[max_idx]
    ax2.axvline(x=max_x, ymin=0, ymax=0.99, color=f'C{i}', linestyle='--', alpha=0.5)

ax2.set_xlabel('Crosstalk (MHz)', fontsize=10, fontweight='bold')
ax2.set_ylabel('F', fontsize=10, fontweight='bold')
ax2.set_xlim(0, x[-1] + 10)
ax2.set_ylim(0.4, 1.05)
ax2.xaxis.set_major_locator(MultipleLocator(20))
ax2.yaxis.set_major_locator(MultipleLocator(0.1))
ax2.tick_params(axis='both', which='major', labelsize=8)
ax2.grid(True, linestyle='--', alpha=0.7)
ax2.set_title('(b)', loc='left', fontsize=10)

plt.tight_layout()
plt.show()
plt.savefig('figure.pdf', bbox_inches='tight')
