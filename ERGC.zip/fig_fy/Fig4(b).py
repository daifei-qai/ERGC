

import matplotlib.pyplot as plt
import numpy as np

# 数据
crosstalk = np.array([0, 0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40])
crosstalktick = np.array([0, 0.1, 0.2, 0.3, 0.4])
fidelitytick = np.array([0.85, 0.90, 0.95, 1.0])
fidelity_xx = [0.999998, 0.999999, 0.999999, 0.999999, 0.999999, 0.999999, 0.99999, 0.999995, 0.999998]
fidelity_hh = [0.999999, 0.999999, 0.999559, 0.999999, 0.999998, 0.999999, 0.999999, 0.999999, 0.999999]
fidelity_xy = [0.999999, 0.999999, 0.999996, 0.999999, 0.999999, 0.999998, 0.999999, 0.999999, 0.999999]
fidelity_hi = [0.999995, 0.999991, 0.999999, 0.999999, 0.999999, 0.999999, 0.999999, 0.999999, 0.999996]
fidelity_no_opti = [0.999974, 0.997593, 0.990485, 0.9787, 0.962365, 0.941681, 0.91692, 0.888424, 0.856598]


segments = np.array([4, 5, 6, 7, 8, 10, 12])
fidelity_opt = [0.999999] * len(segments)
fidelity_no_opt = [0.856598] * len(segments)  # 无优化为常数


# 字体和线型参数
plt.rcParams.update({
    "font.size": 16,
    "axes.labelsize": 16,
    "legend.fontsize": 12,
    "xtick.labelsize": 16,
    "ytick.labelsize": 16,
    "lines.linewidth": 2,
    "axes.linewidth": 1.2,
    "font.family": "serif"
})
fig, ax1 = plt.subplots(figsize=(6, 4))


# 四个门的曲线
ax1.plot(crosstalk, fidelity_hi, marker='D', linestyle=':', color='black', label='HI', markersize=8)
ax1.plot(crosstalk, fidelity_xy, marker='s', linestyle='-.', color='blue', label='XY', markersize=8)
ax1.plot(crosstalk, fidelity_xx, marker='o', linestyle='-', color='green', label='XX', markersize=8)
ax1.plot(crosstalk, fidelity_hh, marker='^', linestyle='--', color='red', label='HH', markersize=8)
# No optimal 曲线
ax1.plot(crosstalk, fidelity_no_opti, marker='*', linestyle='--', color='orange', linewidth=2.5, markersize=13, label='Uncorrected')

# 坐标轴
ax1.set_xlabel(r'$\alpha$')
ax1.set_ylabel('F')
ax1.set_ylim(0.845, 1.01)
ax1.set_xlim(-0.01, 0.41)
ax1.set_xticks(crosstalktick)
ax1.set_yticks(fidelitytick)
ax1.grid(axis='y', linestyle=':', linewidth=1, alpha=0.7)

# legend在图框内左下角，无边框
ax1.legend(loc='lower left', frameon=False, ncol=1)
ax1.tick_params(axis='both', direction='in')



plt.tight_layout()
# 可选：保存为高分辨率PDF
# plt.savefig("gate_fidelity_vs_crosstalk.pdf", bbox_inches='tight')
plt.show()
