import matplotlib.pyplot as plt
import numpy as np

# 数据
noise_strength = np.array([0, 5, 10, 15, 20, 25, 30, 35, 40])
f_no_optimal = [1, 0.996159, 0.984857, 0.96674, 0.942832, 0.914454, 0.883127, 0.850462, 0.818041]
f_dd = [1, 0.999964, 0.999469, 0.997642, 0.993841, 0.9883, 0.982255, 0.977394, 0.974917]
f_ergc = [0.999999, 0.999986, 0.999785, 0.99893, 0.996713, 0.992295, 0.984836, 0.973708, 0.958674]

plt.rcParams.update({
    "font.size": 14,
    "axes.labelsize": 16,
    "legend.fontsize": 13,
    "xtick.labelsize": 14,
    "ytick.labelsize": 14,
    "lines.linewidth": 2,
    "axes.linewidth": 1.2,
    "font.family": "serif"
})

fig, ax = plt.subplots(figsize=(7, 4.2))

ax.plot(noise_strength, f_no_optimal, marker='*', linestyle='-', color='orange', linewidth=2.2, markersize=13, label='No optimal')
ax.plot(noise_strength, f_dd, marker='o', linestyle='--', color='blue', linewidth=2, markersize=8, label='DD')
ax.plot(noise_strength, f_ergc, marker='D', linestyle='-', color='purple', linewidth=2, markersize=8, label='ERGC')

ax.set_xlabel('Noise Strength (MHz)')
ax.set_ylabel(r'$F$')
ax.set_ylim(0.8, 1.01)
ax.set_xlim(-1, 41)
ax.set_xticks(noise_strength)
ax.grid(axis='y', linestyle=':', linewidth=1, alpha=0.7)

ax.legend(loc='lower left', frameon=False)
plt.tight_layout()

# 可选：保存为矢量图
# plt.savefig("fidelity_vs_noise.pdf", bbox_inches='tight')

plt.show()
