import matplotlib.pyplot as plt
import numpy as np
from matplotlib.lines import Line2D

# 数据整理
segments = [4, 5, 6, 7, 8, 10, 12]
data = [
    [0.978099, 0.978249, 0.978099, 0.978099, 0.978268, 0.978199, 0.97811, 0.977994, 0.978282, 0.978099], # 4
    [0.988109, 0.985876, 0.988114, 0.9881, 0.988099, 0.988108, 0.988114, 0.988112, 0.988102, 0.988007],   # 5
    [0.991964, 0.991972, 0.991971, 0.991974, 0.991967, 0.991957, 0.991972, 0.991973, 0.991969, 0.991969], # 6
    [0.99387, 0.993858, 0.993616, 0.99384, 0.993846, 0.993824, 0.993844, 0.993877, 0.99386, 0.993879],    # 7
    [0.994149, 0.994456, 0.99445, 0.994455, 0.994453, 0.994442, 0.994479, 0.994469, 0.994452, 0.993925],  # 8
    [0.993683, 0.993684, 0.993683, 0.993699, 0.993632, 0.9937, 0.993676, 0.993701, 0.993702, 0.9937],     # 10
    [0.993904, 0.993904, 0.9939, 0.992764, 0.993904, 0.992737, 0.993902, 0.992668, 0.993904, 0.99276],    # 12
]


plt.figure(figsize=(5, 3))
box = plt.boxplot(data, patch_artist=True, labels=segments, showmeans=True,
                  meanprops=dict(marker='^', markerfacecolor='green', markeredgecolor='black', markersize=8),
                  flierprops=dict(marker='o', markerfacecolor='orange', markeredgecolor='red', markersize=6, linestyle='none'))

# 箱体颜色
for patch in box['boxes']:
    patch.set_facecolor('lightblue')

# 添加红色虚线
plt.axhline(y=0.975, color='red', linestyle='--', linewidth=2, label='No optimal (y=0.975)')

# 自定义图例元素
legend_elements = [
    Line2D([0], [0], color='red', lw=2, linestyle='--', label='No optimal (y=0.975)'),
    Line2D([0], [0], color='lightblue', lw=10, label='Interquartile range (box)'),
    Line2D([0], [0], marker='^', color='w', label='Mean', markerfacecolor='green', markeredgecolor='black', markersize=10),
    Line2D([0], [0], marker='o', color='w', label='Outlier', markerfacecolor='orange', markeredgecolor='red', markersize=8)
]

plt.xlabel('Segment number', fontsize=12)
plt.ylabel('Fidelity', fontsize=12)
plt.grid(axis='y', linestyle=':', alpha=0.7)
plt.legend(handles=legend_elements, loc='lower right', fontsize=11, frameon=True)

plt.tight_layout()
plt.show()