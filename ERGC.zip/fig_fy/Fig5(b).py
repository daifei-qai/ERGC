# import matplotlib.pyplot as plt

# # 数据
# noise_levels = [0, 5e6, 10e6, 15e6, 20e6, 40e6]
# fidelity_0_4 = [0.999999, 0.99982, 0.999855, 0.999136, 0.9979, 0.982497]
# fidelity_0_2 = [0.999984, 0.999508, 0.999571, 0.998949, 0.997515, 0.976277]
# fidelity_0_0 = [0.999997, 0.999669, 0.998846, 0.997123, 0.994481, 0.966197]

# # 绘制图表
# plt.figure(figsize=(5, 3))
# plt.plot(noise_levels, fidelity_0_4, marker='o', linestyle='-', label='Crosstalk 0.4', color='b')
# plt.plot(noise_levels, fidelity_0_2, marker='s', linestyle='-', label='Crosstalk 0.2', color='g')
# plt.plot(noise_levels, fidelity_0_0, marker='^', linestyle='-', label='Crosstalk 0.0', color='r')

# # 添加标题和标签
# plt.title('Fidelity vs Noise Level', fontsize=14)
# plt.xlabel('Noise Level (Hz)', fontsize=12)
# plt.ylabel('Fidelity', fontsize=12)

# # 添加网格和图例
# plt.grid(True)
# plt.legend()

# # 显示图表
# plt.tight_layout()
# plt.show()

import matplotlib.pyplot as plt

# 数据
noise_levels = [0, 5, 10, 15, 20, 40]  # 单位 MHz
fidelity_0_4 = [0.999999, 0.99982, 0.999855, 0.999136, 0.9979, 0.982497]
fidelity_0_2 = [0.999984, 0.999508, 0.999571, 0.998949, 0.997515, 0.976277]
fidelity_0 = [0.999997, 0.999669, 0.998846, 0.997123, 0.994481, 0.966197]
fidelity_noise_only = [0.99999, 0.998354, 0.993703, 0.98609, 0.975717, 0.912748]

plt.rcParams.update({
    "font.size": 16,
    "axes.labelsize": 16,
    "legend.fontsize": 13,
    "xtick.labelsize": 16,
    "ytick.labelsize": 16,
    "lines.linewidth": 2,
    "axes.linewidth": 1.2,
    "font.family": "serif"
})

fig, ax = plt.subplots()

ax.plot(noise_levels, fidelity_0_4, marker='o', linestyle='-', color='blue', markersize=8, label=r'$\alpha = 0.4$')
ax.plot(noise_levels, fidelity_0_2, marker='s', linestyle='--', color='green', markersize=8, label=r'$\alpha = 0.2$')
ax.plot(noise_levels, fidelity_0, marker='D', linestyle='-.', color='purple', markersize=8, label=r'$\alpha = 0$')
ax.plot(noise_levels, fidelity_noise_only, marker='*', linestyle='--', color='orange', linewidth=2.2, markersize=13, label='Uncorrected')

ax.set_xlabel('$\Delta{\omega}$(MHz)')
ax.set_ylabel('F')
ax.set_ylim(0.9, 1.01)
ax.set_xlim(-1, 41)
ax.set_xticks(noise_levels)
ax.grid(axis='both', linestyle=':', linewidth=1, alpha=0.7)

ax.legend(loc='lower left', frameon=False)
plt.tight_layout()

# 可选：保存为高分辨率PDF
# plt.savefig("fidelity_vs_noise_pra.pdf", bbox_inches='tight')

plt.show()
