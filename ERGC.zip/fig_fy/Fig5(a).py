# import matplotlib.pyplot as plt

# # 数据
# segments = [4, 5, 6, 7, 8, 10, 12]
# fidelities = [0.936477,0.969642,0.980057,0.981451,0.982497,0.986332,0.987366]

# # 绘制图表
# plt.figure(figsize=(4, 3))
# plt.plot(segments, fidelities, marker='o', linestyle='-', color='b', label='Fidelity')

# # 添加标题和标签
# # plt.title('Fidelity vs Segment', fontsize=14)
# plt.xlabel('Segment', fontsize=12)
# plt.ylabel('Fidelity', fontsize=12)

# # 添加网格和图例
# plt.grid(True)
# plt.legend()

# # 显示图表
# plt.tight_layout()
# plt.show()

# import matplotlib.pyplot as plt

# # 数据
# segments = [4, 5, 6, 7, 8, 10, 12]
# fidelities = [0.936477, 0.969642, 0.980057, 0.981451, 0.982497, 0.986332, 0.987366]

# # 绘制图表
# plt.figure(figsize=(4, 3))
# plt.plot(segments, fidelities, marker='o', linestyle='-', color='b', label='Fidelity with optimal')

# # 添加水平虚线
# plt.axhline(y=0.91315, color='r', linestyle='--', label='Fidelity under noise')

# # 添加标题和标签
# # plt.title('Fidelity vs Segment', fontsize=14)
# plt.xlabel('Segment', fontsize=12)
# plt.ylabel('Fidelity', fontsize=12)

# # 设置横轴刻度
# plt.xticks(segments)

# # 添加网格和图例
# plt.grid(True)
# plt.legend()

# # 显示图表
# plt.tight_layout()
# plt.show()


import matplotlib.pyplot as plt

# 数据
segments = [4, 5, 6, 7, 8, 10, 12]
fidelities = [0.936477, 0.969642, 0.980057, 0.981451, 0.982497, 0.986332, 0.987366]
y = [0.91315, 0.91315, 0.91315, 0.91315, 0.91315, 0.91315, 0.91315]

plt.rcParams.update({
    "font.size": 16,
    "axes.labelsize": 16,
    "legend.fontsize": 12,
    "xtick.labelsize": 16,
    "ytick.labelsize": 16,
    "lines.linewidth": 2,
    "axes.linewidth": 1.2,
    "font.family": "serif"
})

#plt.figure(figsize=(4, 3))

plt.plot(segments, fidelities, marker='o', linestyle='-', color='purple', markersize=7, label='ERGC')
plt.plot(segments,y,marker='*',color='orange', linestyle='--', linewidth=2, label='Uncorrected')
# 添加橙色水平虚线
#plt.axhline(y=0.91315, color='orange', linestyle='--', linewidth=2, label='Uncorrected')
plt.tick_params(axis='both', direction='in')
plt.xlabel(r'n')
plt.ylabel(r'F')
plt.xticks(segments)
plt.ylim(0.91, 1.00)
plt.grid(axis='y', linestyle=':', alpha=0.7)

plt.legend(loc='center right', frameon=False)
plt.tight_layout()
plt.show()

