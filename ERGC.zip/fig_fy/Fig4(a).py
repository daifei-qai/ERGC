# import matplotlib.pyplot as plt
# import numpy as np

# # 数据
# segments = np.array([4, 5, 6, 7, 8, 10, 12])
# fidelity_opt = [0.999999, 0.999999, 0.999999, 0.999999, 0.999999, 0.999999, 0.999999]
# fidelity_no_opt = [0.856598] * len(segments)  # 无优化为常数

# plt.figure(figsize=(6, 3))
# plt.plot(segments, fidelity_opt, marker='o', linestyle='-', color='purple', label='ERC Optimal')
# plt.plot(segments, fidelity_no_opt, marker='*', linestyle='--', color='orange', linewidth=2, markersize=11, label='No optimial')

# plt.xlabel('Number of Segments', fontsize=13)
# plt.ylabel('Fidelity', fontsize=13)
# plt.title('Fidelity vs. Number of Segments', fontsize=14)
# plt.ylim(0.85, 1.01)
# plt.xticks(segments)
# plt.grid(axis='y', linestyle=':', alpha=0.7)
# plt.legend(loc='lower right', fontsize=12, frameon=True)
# plt.tight_layout()

# # 可选：保存为高分辨率PDF
# # plt.savefig("fidelity_vs_segments.pdf", bbox_inches='tight')

# plt.show()

import matplotlib.pyplot as plt
import numpy as np

# 数据
segments = np.array([4, 5, 6, 7, 8, 10, 12])
fidelityticks = np.array([0.85, 0.90, 0.95, 1.0])
fidelity_opt = [0.999999] * len(segments)
fidelity_no_opt = [0.856598] * len(segments)  # 无优化为常数

# 图形参数，符合PRA标准
plt.rcParams.update({
    "font.size": 16,
    "axes.labelsize": 16,
    "legend.fontsize": 12,
    "xtick.labelsize": 16,
    "ytick.labelsize": 16,
    "lines.linewidth": 2,
    "axes.linewidth": 1.2,
    "font.family": "serif"
})

fig, ax = plt.subplots(figsize=(6, 3))

# 优化后数据
ax.plot(segments, fidelity_opt, marker='o', linestyle='-', color='purple', label='ERGC', markersize=8)
# 无优化数据
ax.plot(segments, fidelity_no_opt, marker='*', linestyle='--', color='orange', linewidth=2, markersize=12, label='Uncorrected')

# 坐标轴设置
ax.set_xlabel(r'n')
ax.set_ylabel(r'F')
ax.set_ylim(0.845, 1.01)
ax.set_xlim(3.5, 12.5)
ax.set_xticks(segments)
ax.set_yticks(fidelityticks)
ax.grid(axis='y', linestyle=':', linewidth=1, alpha=0.7)

# legend放在图框内右侧中间
ax.legend(loc='center right', frameon=False)
ax.tick_params(axis='both', direction='in')
plt.tight_layout()
plt.show()

