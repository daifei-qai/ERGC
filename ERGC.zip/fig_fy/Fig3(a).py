import matplotlib.pyplot as plt
import numpy as np

# 数据
n = np.array([4, 5, 6, 7, 8, 10, 12])
optimal = np.array([0.978099, 0.988109, 0.991964, 0.99387, 0.994149, 0.993702, 0.993904])
no_optimal = np.array([0.97585,0.97585,0.97585,0.97585,0.97585,0.97585,0.97585])

# 图形参数
plt.rcParams.update({
    "font.size": 16,
    "axes.labelsize": 16,
    "legend.fontsize": 12,
    "xtick.labelsize": 16,
    "ytick.labelsize": 16,
    "lines.linewidth": 2,
    "axes.linewidth": 1.2,
    "font.family": "serif"
})

fig, ax = plt.subplots()

# 优化后数据
ax.plot(n, optimal, marker='o', color='purple', label='ERGC', markersize=7)
ax.plot(n, no_optimal, marker='*', color='orange', linestyle='--', markersize=7,linewidth=2, label='Uncorrected')
# no optimal水平线
#ax.axhline(no_optimal, color='orange', linestyle='--', linewidth=2, label='No optimal')

# 坐标轴与标签
ax.set_xlabel('n')
ax.set_ylabel('F')
ax.set_xlim(3.5, 12.5)
ax.set_ylim(0.97, 1.0)
ax.set_xticks(n)
ax.set_yticks([0.97,0.98,0.99,1.0])
ax.grid(True, linestyle=':', linewidth=1, alpha=0.6)
ax.legend(loc='center right', frameon=False)

plt.tight_layout()
plt.show()
